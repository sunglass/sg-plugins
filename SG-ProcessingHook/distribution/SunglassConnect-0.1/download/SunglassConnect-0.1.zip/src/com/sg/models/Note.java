package com.sg.models;

public class Note {

}
